/-
Copyright (c) 2026 The Tau Ceti contributors. All rights reserved.
Released under Apache 2.0 license as described in the file LICENSE.
Authors: The Tau Ceti contributors
-/
module

public import Mathlib.Analysis.InnerProductSpace.Positive
public import Mathlib.Analysis.InnerProductSpace.Spectrum
public import TauCeti.Analysis.InnerProductSpace.HilbertBasis.Basic
public import TauCeti.Analysis.InnerProductSpace.BasisSpan
public import TauCeti.Data.Fin.Tuple.Sort
public import TauCeti.LinearAlgebra.Eigenspace.Anticommute
import Mathlib.LinearAlgebra.Eigenspace.ContinuousLinearMap

/-!
# Spectral decompositions of self-adjoint operators

Mathlib's spectral theorem for a compact self-adjoint operator `T` on a Hilbert space `E` says
that the eigenspaces of `T` have trivial mutual orthogonal complement
(`ContinuousLinearMap.orthogonalComplement_iSup_eigenspaces_eq_bot`) and that the eigenspaces at
nonzero eigenvalues are finite dimensional
(`ContinuousLinearMap.finite_dimensional_eigenspace`).  This file turns the first statement into
the form the applications want: **`E` has an orthonormal basis consisting of eigenvectors of
`T`**.

The construction is the classical one.  Each eigenspace is closed, hence a Hilbert space in its
own right, so it has a Hilbert basis; the eigenspaces are mutually orthogonal, so the union of
those bases is an orthonormal family; and a vector orthogonal to the whole family is orthogonal
to every eigenspace, hence zero.  `HilbertBasis.mkOfOrthogonalEqBot` then assembles the family
into a Hilbert basis of `E`.

In finite dimensions, this file also packages Mathlib's ordered eigenbasis into the spans of
any chosen set of its eigenvectors. In particular, the negative and positive spectral subspaces,
spanned by the eigenvectors with negative and with positive eigenvalue, are disjoint, invariant
under the operator, and together span the whole space when the operator is injective. Writing
the determinant as the product of the eigenvalues shows that a positive operator has nonnegative
determinant, and its smallest eigenvalue, the infimum of the Rayleigh quotient, bounds an injective
positive operator below. If an invertible operator anticommutes with the symmetric operator, as a
complex structure anticommutes with the shape operator of a complex submanifold, then the ordered
eigenvalues are antisymmetric, so the positive and negative spectral subspaces have equal
dimension.

No separability is assumed anywhere: the basis is indexed by a set of vectors of `E`, exactly as
in Mathlib's `exists_hilbertBasis`, and the eigenvalue `0` may well carry an infinite-dimensional
eigenspace.  When `T` is injective that eigenspace is trivial and every basis vector has a
nonzero eigenvalue, which is the form the eigenvalue problem of an elliptic operator uses.

## Main declarations

* `ContinuousLinearMap.exists_hilbertBasis_forall_hasEigenvector_of_dense_eigenspaces`:
  a symmetric operator whose eigenspaces have dense span admits a Hilbert basis of eigenvectors.
* `ContinuousLinearMap.exists_hilbertBasis_forall_hasEigenvector`: the compact symmetric
  specialization of the preceding result.
* `ContinuousLinearMap.exists_hilbertBasis_forall_hasEigenvector_ne_zero`: for an injective compact
  symmetric operator, every vector of that basis has a nonzero eigenvalue.
* `ContinuousLinearMap.hasSum_smul_repr_of_apply_eq_smul`: an operator diagonal in a Hilbert
  basis is the sum of its eigencomponents, the spectral expansion such a basis is for.
* `LinearMap.IsSymmetric.inner_sub_apply_of_apply_eq_smul_of_apply_eq_smul`: the cross term of
  the difference of two operators on eigenvectors is the eigenvalue difference times their inner
  product.
* `LinearMap.IsSymmetric.eigenvectorSpan`: the span of the eigenvectors of the ordered
  eigenbasis whose indices lie in a specified set.
* `LinearMap.IsSymmetric.negativeSpectralSubspace` and
  `LinearMap.IsSymmetric.positiveSpectralSubspace`: the negative and positive halves of the
  finite-dimensional spectral splitting.
* `LinearMap.IsSymmetric.eigenvalues_rev_of_anticommute`: if an invertible operator anticommutes
  with `T`, the `i`-th largest eigenvalue of `T` is minus its `i`-th smallest.
* `finrank_positiveSpectralSubspace_eq_finrank_negativeSpectralSubspace_of_anticommute`, in the
  same namespace: in that case the positive and negative spectral subspaces have the same
  dimension.
* `LinearMap.IsPositive.det_nonneg`: a positive operator on a finite-dimensional space has
  nonnegative determinant, the product of its eigenvalues.
* `LinearMap.IsPositive.det_pos`: an injective positive operator on a finite-dimensional space has
  positive determinant.
* `LinearMap.IsPositive.exists_pos_mul_norm_sq_le_re_inner`: an injective positive operator on a
  finite-dimensional space is coercive.
* `ContinuousLinearMap.IsPositive.det_one_sub_smul_id_add_smul_pos`: interpolating the identity
  with a positive operator `A` as `(1 - t) • 1 + t • A`, `0 ≤ t < 1`, gives positive determinant.

## References

H. Brezis, *Functional Analysis, Sobolev Spaces and Partial Differential Equations*,
Theorem 6.11 (the Hilbert--Schmidt spectral decomposition); L. C. Evans, *Partial Differential
Equations*, Appendix D.6.

The eigenvector cross-term identity
`LinearMap.IsSymmetric.inner_sub_apply_of_apply_eq_smul_of_apply_eq_smul` is adapted from the
corresponding eigenvector identity of the
[AIQ-Kitware DKPS formalization](https://github.com/AIQ-Kitware/aiq-dkps-formalization)
(Kitware, Inc.; Apache-2.0), generalized here to `RCLike` scalars and a non-symmetric second
operator.
-/

public section

open Module.End
open scoped InnerProductSpace

variable {𝕜 E : Type*} [RCLike 𝕜] [NormedAddCommGroup E] [InnerProductSpace 𝕜 E]

namespace ContinuousLinearMap

variable [CompleteSpace E] {T : E →L[𝕜] E}

/-- **A symmetric operator whose eigenspaces have dense span has an orthonormal basis of
eigenvectors.**  The basis is indexed by a set of vectors of `E`, as in `exists_hilbertBasis`,
and no separability is assumed. -/
theorem exists_hilbertBasis_forall_hasEigenvector_of_dense_eigenspaces
    (hT' : (T : E →ₗ[𝕜] E).IsSymmetric)
    (hspan : (⨆ mu, eigenspace (T : Module.End 𝕜 E) mu)ᗮ = ⊥) :
    ∃ (s : Set E) (b : HilbertBasis s 𝕜 E) (nu : s → 𝕜), ⇑b = ((↑) : s → E) ∧
      ∀ x : s, HasEigenvector (T : Module.End 𝕜 E) (nu x) (x : E) := by
  classical
  have hbasis : ∀ mu : 𝕜, ∃ (w : Set (eigenspace (T : Module.End 𝕜 E) mu))
      (b : HilbertBasis w 𝕜 (eigenspace (T : Module.End 𝕜 E) mu)),
      ⇑b = ((↑) : w → eigenspace (T : Module.End 𝕜 E) mu) := by
    intro mu
    have : CompleteSpace (eigenspace (T : Module.End 𝕜 E) mu) :=
      (isClosed_eigenspace T mu).completeSpace_coe
    exact exists_hilbertBasis 𝕜 _
  choose w bw _ using hbasis
  set v : (Σ mu : 𝕜, w mu) → E := fun p =>
    (eigenspace (T : Module.End 𝕜 E) p.1).subtypeₗᵢ (bw p.1 p.2)
  have hv : Orthonormal 𝕜 v :=
    hT'.orthogonalFamily_eigenspaces.orthonormal_sigma_orthonormal fun mu => (bw mu).orthonormal
  have hinj : Function.Injective v := hv.linearIndependent.injective
  have hmem : ∀ p, v p ∈ eigenspace (T : Module.End 𝕜 E) p.1 := fun p => (bw p.1 p.2).2
  have hvspan : (Submodule.span 𝕜 (Set.range v))ᗮ = ⊥ := by
    refine le_antisymm ?_ bot_le
    rw [← hspan, ← Submodule.iInf_orthogonal]
    intro x hx
    have hx' : ∀ p, ⟪x, v p⟫_𝕜 = 0 := fun p =>
      (Submodule.mem_orthogonal' _ x).mp hx _ (Submodule.subset_span ⟨p, rfl⟩)
    simp only [Submodule.mem_iInf]
    intro mu
    rw [Submodule.mem_orthogonal']
    exact fun y hy =>
      (bw mu).inner_eq_zero_of_forall_inner_eq_zero (fun i => hx' ⟨mu, i⟩) hy
  have key : ∀ x : Set.range v, ∃ mu : 𝕜, HasEigenvector (T : Module.End 𝕜 E) mu (x : E) := by
    rintro ⟨-, p, rfl⟩
    refine ⟨p.1, hmem p, fun hzero => ?_⟩
    have hzero' : v p = 0 := hzero
    have hnorm : ‖v p‖ = 1 := hv.1 p
    rw [hzero', norm_zero] at hnorm
    exact zero_ne_one hnorm
  choose nu hnu using key
  exact ⟨Set.range v, HilbertBasis.mkOfOrthogonalEqBot ((orthonormal_subtype_range hinj).2 hv)
    (by rwa [Subtype.range_coe]), nu, HilbertBasis.coe_mkOfOrthogonalEqBot _ _, hnu⟩

/-- **A compact self-adjoint operator has an orthonormal basis of eigenvectors.** -/
theorem exists_hilbertBasis_forall_hasEigenvector (hT : IsCompactOperator T)
    (hT' : (T : E →ₗ[𝕜] E).IsSymmetric) :
    ∃ (s : Set E) (b : HilbertBasis s 𝕜 E) (nu : s → 𝕜), ⇑b = ((↑) : s → E) ∧
      ∀ x : s, HasEigenvector (T : Module.End 𝕜 E) (nu x) (x : E) :=
  exists_hilbertBasis_forall_hasEigenvector_of_dense_eigenspaces hT'
    (ContinuousLinearMap.orthogonalComplement_iSup_eigenspaces_eq_bot hT hT')

/-- **An injective symmetric operator whose eigenspaces have dense span has an orthonormal basis
of eigenvectors with nonzero eigenvalues.** -/
theorem exists_hilbertBasis_forall_hasEigenvector_ne_zero_of_dense_eigenspaces
    (hT' : (T : E →ₗ[𝕜] E).IsSymmetric)
    (hspan : (⨆ mu, eigenspace (T : Module.End 𝕜 E) mu)ᗮ = ⊥)
    (hker : LinearMap.ker (T : E →ₗ[𝕜] E) = ⊥) :
    ∃ (s : Set E) (b : HilbertBasis s 𝕜 E) (nu : s → 𝕜), ⇑b = ((↑) : s → E) ∧
      (∀ x : s, nu x ≠ 0) ∧ ∀ x : s, HasEigenvector (T : Module.End 𝕜 E) (nu x) (x : E) := by
  obtain ⟨s, b, nu, hb, hev⟩ :=
    exists_hilbertBasis_forall_hasEigenvector_of_dense_eigenspaces hT' hspan
  refine ⟨s, b, nu, hb, fun x hx => ?_, hev⟩
  have hx0 : (x : E) ∈ LinearMap.ker (T : E →ₗ[𝕜] E) := by
    rw [← eigenspace_zero, ← hx]
    exact (hev x).1
  rw [hker, Submodule.mem_bot] at hx0
  exact (hev x).2 hx0

/-- **An injective compact self-adjoint operator has an orthonormal basis of eigenvectors with
nonzero eigenvalues.**  Injectivity excludes the eigenvalue `0`. -/
theorem exists_hilbertBasis_forall_hasEigenvector_ne_zero (hT : IsCompactOperator T)
    (hT' : (T : E →ₗ[𝕜] E).IsSymmetric) (hker : LinearMap.ker (T : E →ₗ[𝕜] E) = ⊥) :
    ∃ (s : Set E) (b : HilbertBasis s 𝕜 E) (nu : s → 𝕜), ⇑b = ((↑) : s → E) ∧
      (∀ x : s, nu x ≠ 0) ∧ ∀ x : s, HasEigenvector (T : Module.End 𝕜 E) (nu x) (x : E) :=
  exists_hilbertBasis_forall_hasEigenvector_ne_zero_of_dense_eigenspaces
    hT' (ContinuousLinearMap.orthogonalComplement_iSup_eigenspaces_eq_bot hT hT') hker

omit [CompleteSpace E] in
/-- **The spectral expansion of an operator diagonal in a Hilbert basis.**  Applying `T` term by
term to the expansion of `y` writes `T y` as the sum of its eigencomponents; combined with
`ContinuousLinearMap.exists_hilbertBasis_forall_hasEigenvector` this diagonalizes a compact
self-adjoint operator. -/
theorem hasSum_smul_repr_of_apply_eq_smul (T : E →L[𝕜] E) {iota : Type*}
    (b : HilbertBasis iota 𝕜 E)
    (nu : iota → 𝕜) (hb : ∀ i, T (b i) = nu i • b i) (y : E) :
    HasSum (fun i => nu i • b.repr y i • b i) (T y) := by
  have key : ∀ i, T (b.repr y i • b i) = nu i • b.repr y i • b i := fun i => by
    rw [map_smul, hb, smul_comm]
  simpa only [key] using T.hasSum (b.hasSum_repr y)

end ContinuousLinearMap

namespace LinearMap.IsSymmetric

/-! ### Eigenvector identities -/

/-- The cross term of an operator difference on eigenvectors is the eigenvalue difference times
their inner product.

Only the operator acting on the first eigenvector needs to be symmetric, and the eigenvalues may
be arbitrary scalars: the eigenvalue of a symmetric operator at a nonzero eigenvector is real.
In particular, this applies when both operators are symmetric, as in eigenvalue perturbation
arguments. -/
theorem inner_sub_apply_of_apply_eq_smul_of_apply_eq_smul {T S : E →ₗ[𝕜] E}
    (hT : T.IsSymmetric) {x y : E} {lam mu : 𝕜} (hx : T x = lam • x) (hy : S y = mu • y) :
    ⟪x, (S - T) y⟫_𝕜 = (mu - lam) * ⟪x, y⟫_𝕜 := by
  rcases eq_or_ne x 0 with rfl | hx0
  · simp
  have hlam : starRingEnd 𝕜 lam = lam :=
    hT.conj_eigenvalue_eq_self (hasEigenvalue_of_hasEigenvector ⟨mem_eigenspace_iff.mpr hx, hx0⟩)
  calc ⟪x, (S - T) y⟫_𝕜 = ⟪x, S y⟫_𝕜 - ⟪T x, y⟫_𝕜 := by
        rw [LinearMap.sub_apply, inner_sub_right, hT x y]
    _ = (mu - lam) * ⟪x, y⟫_𝕜 := by
        rw [hx, hy, inner_smul_right, inner_smul_left, hlam, sub_mul]

variable {n : ℕ} [FiniteDimensional 𝕜 E] {T : E →ₗ[𝕜] E}

/-! ### Finite-dimensional eigenvector spans -/

/-- The span of the eigenvectors whose indices belong to `s`.

The eigenvectors are those of Mathlib's decreasingly ordered eigenbasis, so this span depends on
that basis and may select only part of a repeated eigenspace. It is particularly useful with
subsets cut out by inequalities on the corresponding eigenvalues. -/
noncomputable def eigenvectorSpan (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    (s : Set (Fin n)) : Submodule 𝕜 E :=
  Submodule.span 𝕜 (hT.eigenvectorBasis hn '' s)

/-- The selected eigenvector span is the span of the same indices in the orthonormal basis. -/
theorem eigenvectorSpan_eq_spanIndices (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) (s : Set (Fin n)) :
    hT.eigenvectorSpan hn s = (hT.eigenvectorBasis hn).spanIndices s := by
  rw [eigenvectorSpan, OrthonormalBasis.spanIndices_eq_span]

/-- The span of the eigenvectors at embedded indices equals their canonical eigenvector span. -/
theorem span_range_eigenvectorBasis_apply_eq_eigenvectorSpan (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) {ι : Type*} (e : ι ↪ Fin n) :
    Submodule.span 𝕜 (Set.range fun i => hT.eigenvectorBasis hn (e i)) =
      hT.eigenvectorSpan hn (Set.range e) := by
  rw [eigenvectorSpan, ← Set.range_comp, Function.comp_def]

/-- A vector belongs to an eigenvector span exactly when its eigenbasis representation is
supported on the selected indices. -/
@[simp]
theorem mem_eigenvectorSpan_iff (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    {s : Set (Fin n)} {v : E} :
    v ∈ hT.eigenvectorSpan hn s ↔
      ↑((hT.eigenvectorBasis hn).toBasis.repr v).support ⊆ s := by
  rw [eigenvectorSpan, ← OrthonormalBasis.coe_toBasis]
  exact Module.Basis.mem_span_image (b := (hT.eigenvectorBasis hn).toBasis)

/-- An eigenvector from the ordered eigenbasis belongs to an eigenvector span exactly when its
index is selected. -/
theorem eigenvectorBasis_mem_eigenvectorSpan_iff (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) {s : Set (Fin n)} (i : Fin n) :
    hT.eigenvectorBasis hn i ∈ hT.eigenvectorSpan hn s ↔ i ∈ s := by
  rw [eigenvectorSpan, ← OrthonormalBasis.coe_toBasis]
  exact Module.Basis.self_mem_span_image (b := (hT.eigenvectorBasis hn).toBasis)

/-- Enlarging the set of eigenvector indices enlarges its span. -/
theorem eigenvectorSpan_mono (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    {s t : Set (Fin n)} (hst : s ⊆ t) :
    hT.eigenvectorSpan hn s ≤ hT.eigenvectorSpan hn t :=
  Submodule.span_mono (Set.image_mono hst)

/-- The eigenvector span of a union is the sum of the two eigenvector spans. -/
@[simp]
theorem eigenvectorSpan_union (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    (s t : Set (Fin n)) :
    hT.eigenvectorSpan hn (s ∪ t) = hT.eigenvectorSpan hn s ⊔ hT.eigenvectorSpan hn t := by
  rw [eigenvectorSpan, eigenvectorSpan, eigenvectorSpan, Set.image_union,
    Submodule.span_union]

/-- The eigenvector span of the empty set is zero. -/
@[simp]
theorem eigenvectorSpan_empty (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n) :
    hT.eigenvectorSpan hn ∅ = ⊥ := by
  simp [eigenvectorSpan]

/-- All eigenvectors together span the whole finite-dimensional inner product space. -/
@[simp]
theorem eigenvectorSpan_univ (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n) :
    hT.eigenvectorSpan hn Set.univ = ⊤ := by
  rw [eigenvectorSpan, ← OrthonormalBasis.coe_toBasis, Set.image_univ]
  exact (hT.eigenvectorBasis hn).toBasis.span_eq

/-- Eigenvector spans indexed by disjoint sets are disjoint. -/
theorem disjoint_eigenvectorSpan (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    {s t : Set (Fin n)} (hst : Disjoint s t) :
    Disjoint (hT.eigenvectorSpan hn s) (hT.eigenvectorSpan hn t) :=
  (hT.eigenvectorBasis hn).toBasis.linearIndependent.disjoint_span_image hst

/-- The dimension of an eigenvector span is the number of eigenvectors selected. -/
@[simp]
theorem finrank_eigenvectorSpan (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    (s : Set (Fin n)) :
    Module.finrank 𝕜 (hT.eigenvectorSpan hn s) = s.ncard := by
  classical
  rw [eigenvectorSpan, ← OrthonormalBasis.coe_toBasis, finrank_span_set_eq_card
    ((hT.eigenvectorBasis hn).toBasis.linearIndependent.linearIndepOn _ |>.id_image)]
  calc
    ((hT.eigenvectorBasis hn).toBasis '' s).toFinset.card =
        ((hT.eigenvectorBasis hn).toBasis '' s).ncard :=
      (Set.ncard_eq_toFinset_card' _).symm
    _ = s.ncard :=
      Set.ncard_image_of_injective s (hT.eigenvectorBasis hn).toBasis.injective

/-- A symmetric operator preserves each of its eigenvector spans. -/
theorem map_eigenvectorSpan_le (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    (s : Set (Fin n)) :
    Submodule.map T (hT.eigenvectorSpan hn s) ≤ hT.eigenvectorSpan hn s := by
  rw [eigenvectorSpan, Submodule.map_span_le]
  rintro _ ⟨i, hi, rfl⟩
  rw [hT.apply_eigenvectorBasis hn i]
  exact Submodule.smul_mem _ _ (Submodule.subset_span ⟨i, hi, rfl⟩)

/-- The negative spectral subspace of a finite-dimensional symmetric operator: the span of the
eigenvectors with negative eigenvalue. -/
noncomputable def negativeSpectralSubspace (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) : Submodule 𝕜 E :=
  hT.eigenvectorSpan hn {i | hT.eigenvalues hn i < 0}

/-- The positive spectral subspace of a finite-dimensional symmetric operator: the span of the
eigenvectors with positive eigenvalue. -/
noncomputable def positiveSpectralSubspace (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) : Submodule 𝕜 E :=
  hT.eigenvectorSpan hn {i | 0 < hT.eigenvalues hn i}

/-- A vector belongs to the negative spectral subspace exactly when its eigenbasis representation
is supported on the negative eigenvalues. -/
@[simp]
theorem mem_negativeSpectralSubspace_iff (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    {v : E} :
    v ∈ hT.negativeSpectralSubspace hn ↔
      ∀ i ∈ ((hT.eigenvectorBasis hn).toBasis.repr v).support, hT.eigenvalues hn i < 0 := by
  rw [negativeSpectralSubspace, mem_eigenvectorSpan_iff]
  exact Iff.rfl

/-- A vector belongs to the positive spectral subspace exactly when its eigenbasis representation
is supported on the positive eigenvalues. -/
@[simp]
theorem mem_positiveSpectralSubspace_iff (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    {v : E} :
    v ∈ hT.positiveSpectralSubspace hn ↔
      ∀ i ∈ ((hT.eigenvectorBasis hn).toBasis.repr v).support, 0 < hT.eigenvalues hn i := by
  rw [positiveSpectralSubspace, mem_eigenvectorSpan_iff]
  exact Iff.rfl

/-- The dimension of the negative spectral subspace counts the negative eigenvalues, with
multiplicity. -/
@[simp]
theorem finrank_negativeSpectralSubspace (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) :
    Module.finrank 𝕜 (hT.negativeSpectralSubspace hn) =
      {i | hT.eigenvalues hn i < 0}.ncard := by
  rw [negativeSpectralSubspace]
  exact hT.finrank_eigenvectorSpan hn _

/-- The dimension of the positive spectral subspace counts the positive eigenvalues, with
multiplicity. -/
@[simp]
theorem finrank_positiveSpectralSubspace (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) :
    Module.finrank 𝕜 (hT.positiveSpectralSubspace hn) =
      {i | 0 < hT.eigenvalues hn i}.ncard := by
  rw [positiveSpectralSubspace]
  exact hT.finrank_eigenvectorSpan hn _

/-- A symmetric operator preserves its negative spectral subspace. -/
theorem map_negativeSpectralSubspace_le (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) :
    Submodule.map T (hT.negativeSpectralSubspace hn) ≤ hT.negativeSpectralSubspace hn := by
  rw [negativeSpectralSubspace]
  exact hT.map_eigenvectorSpan_le hn _

/-- A symmetric operator preserves its positive spectral subspace. -/
theorem map_positiveSpectralSubspace_le (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) :
    Submodule.map T (hT.positiveSpectralSubspace hn) ≤ hT.positiveSpectralSubspace hn := by
  rw [positiveSpectralSubspace]
  exact hT.map_eigenvectorSpan_le hn _

/-- The negative and positive spectral subspaces are disjoint. -/
theorem disjoint_negativeSpectralSubspace_positiveSpectralSubspace
    (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n) :
    Disjoint (hT.negativeSpectralSubspace hn) (hT.positiveSpectralSubspace hn) := by
  rw [negativeSpectralSubspace, positiveSpectralSubspace]
  exact hT.disjoint_eigenvectorSpan hn
    (Set.disjoint_left.2 fun i (hneg : hT.eigenvalues hn i < 0)
      (hpos : 0 < hT.eigenvalues hn i) ↦ (not_lt_of_ge hpos.le) hneg)

/-- An injective symmetric operator has no zero eigenvalue in its ordered eigenvalue family. -/
theorem eigenvalues_ne_zero_of_ker_eq_bot (hT : T.IsSymmetric)
    (hn : Module.finrank 𝕜 E = n) (hker : LinearMap.ker T = ⊥) (i : Fin n) :
    hT.eigenvalues hn i ≠ 0 := by
  intro hi
  have hev := hT.hasEigenvalue_eigenvalues hn i
  rw [hi, RCLike.ofReal_zero, Module.End.hasEigenvalue_iff, Module.End.eigenspace_zero,
    hker] at hev
  exact hev rfl

/-- For an injective symmetric operator, its negative and positive spectral subspaces are
complementary: they are disjoint and together span the whole space. -/
theorem isCompl_negativeSpectralSubspace_positiveSpectralSubspace_of_ker_eq_bot
    (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n) (hker : LinearMap.ker T = ⊥) :
    IsCompl (hT.negativeSpectralSubspace hn) (hT.positiveSpectralSubspace hn) := by
  refine ⟨hT.disjoint_negativeSpectralSubspace_positiveSpectralSubspace hn, codisjoint_iff.2 ?_⟩
  rw [negativeSpectralSubspace, positiveSpectralSubspace, ← hT.eigenvectorSpan_union hn]
  have hindices : {i | hT.eigenvalues hn i < 0} ∪
      {i | 0 < hT.eigenvalues hn i} = Set.univ := by
    ext i
    simp only [Set.mem_union, Set.mem_ofPred, Set.mem_univ, iff_true]
    exact lt_or_gt_of_ne (hT.eigenvalues_ne_zero_of_ker_eq_bot hn hker i)
  rw [hindices, hT.eigenvectorSpan_univ hn]

/-! ### Operators anticommuting with an invertible operator -/

open Finset in
/-- **Paired eigenvalues.** If an invertible operator `e` anticommutes with a symmetric operator
`T`, the decreasingly ordered eigenvalues of `T` are antisymmetric: the `i`-th largest eigenvalue
is minus the `i`-th smallest one. Equivalently, the eigenvalues of `T`, counted with
multiplicity, are symmetric about `0`. -/
theorem eigenvalues_rev_of_anticommute (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n)
    (e : E ≃ₗ[𝕜] E) (h : T * e + e * T = 0) (i : Fin n) :
    hT.eigenvalues hn i.rev = -hT.eigenvalues hn i := by
  classical
  -- The real number `-μ` occurs as often as `μ` in the ordered eigenvalue family.
  have hcount (μ : ℝ) :
      #{j | hT.eigenvalues hn j = -μ} = #{j | hT.eigenvalues hn j = μ} := by
    have hcard (ν : ℝ) :
        #{j | hT.eigenvalues hn j = ν} = Module.finrank 𝕜 (eigenspace T (ν : 𝕜)) := by
      rw [← hT.card_filter_eigenvalues_eq hn]
      simp only [RCLike.ofReal_inj]
    rw [hcard, hcard, RCLike.ofReal_neg, finrank_genEigenspace_neg_of_anticommute e h]
  -- The family `j ↦ -λ_{rev j}` is again decreasing, and every value occurs in it as often as
  -- in the ordered eigenvalue family, so it is that family itself.
  have hgev : (fun j ↦ -hT.eigenvalues hn j.rev) = hT.eigenvalues hn := by
    refine Antitone.eq_of_card_filter_eq
      (fun j k hjk ↦ neg_le_neg (hT.eigenvalues_antitone hn (Fin.rev_le_rev.2 hjk)))
      (hT.eigenvalues_antitone hn) fun μ ↦ ?_
    rw [← hcount μ]
    refine Finset.card_equiv Fin.revPerm fun j ↦ ?_
    simp only [Finset.mem_filter, Finset.mem_univ, true_and, Fin.revPerm_apply]
    constructor <;> intro hj <;> linarith
  simpa using (congrFun hgev i.rev).symm

/-- If an invertible operator anticommutes with a symmetric operator `T`, then `T` has as many
positive as negative eigenvalues, counted with multiplicity: its positive and negative spectral
subspaces have the same dimension. -/
theorem finrank_positiveSpectralSubspace_eq_finrank_negativeSpectralSubspace_of_anticommute
    (hT : T.IsSymmetric) (hn : Module.finrank 𝕜 E = n) (e : E ≃ₗ[𝕜] E) (h : T * e + e * T = 0) :
    Module.finrank 𝕜 (hT.positiveSpectralSubspace hn) =
      Module.finrank 𝕜 (hT.negativeSpectralSubspace hn) := by
  rw [finrank_positiveSpectralSubspace, finrank_negativeSpectralSubspace]
  refine Set.ncard_congr (fun i _ ↦ i.rev) (fun i hi ↦ ?_) (fun _ _ _ _ ↦ Fin.rev_inj.1)
    fun j hj ↦ ⟨j.rev, ?_, Fin.rev_rev j⟩
  · simpa [hT.eigenvalues_rev_of_anticommute hn e h] using hi
  · simpa [hT.eigenvalues_rev_of_anticommute hn e h] using hj

end LinearMap.IsSymmetric

namespace LinearMap.IsPositive

open scoped ComplexOrder

variable [FiniteDimensional 𝕜 E] {T : E →ₗ[𝕜] E}

/-- A positive operator on a finite-dimensional inner product space has nonnegative determinant:
the determinant is the product of the eigenvalues, which are nonnegative. -/
theorem det_nonneg (hT : T.IsPositive) : 0 ≤ T.det := by
  rw [hT.isSymmetric.det_eq_prod_eigenvalues rfl, ← RCLike.ofReal_prod]
  exact RCLike.ofReal_nonneg.2 (Finset.prod_nonneg fun i _ => hT.nonneg_eigenvalues rfl i)

/-- An injective positive operator on a finite-dimensional inner product space has positive
determinant. -/
theorem det_pos (hT : T.IsPositive) (hker : LinearMap.ker T = ⊥) : 0 < T.det :=
  lt_of_le_of_ne hT.det_nonneg fun h => LinearMap.det_eq_zero_iff_ker_ne_bot.1 h.symm hker

/-- An injective positive operator on a finite-dimensional inner product space is coercive:
`c ‖v‖ ^ 2 ≤ re ⟪T v, v⟫` for some `c > 0`, namely its smallest eigenvalue. -/
theorem exists_pos_mul_norm_sq_le_re_inner (hT : T.IsPositive) (hker : LinearMap.ker T = ⊥) :
    ∃ c > 0, ∀ v, c * ‖v‖ ^ 2 ≤ RCLike.re ⟪T v, v⟫_𝕜 := by
  rcases subsingleton_or_nontrivial E with hE | hE
  · exact ⟨1, one_pos, fun v => by simp [Subsingleton.elim v 0]⟩
  -- The infimum `c` of the Rayleigh quotient is an eigenvalue, nonzero by injectivity.
  set c := ⨅ x : {x : E // x ≠ 0}, RCLike.re ⟪T x, x⟫_𝕜 / ‖(x : E)‖ ^ 2
  obtain ⟨v, hv⟩ := hT.isSymmetric.hasEigenvalue_iInf_of_finiteDimensional.exists_hasEigenvector
  have hTv : T v = (c : 𝕜) • v := hv.apply_eq_smul
  have hc0 : c ≠ 0 := fun h => hv.2 (LinearMap.ker_eq_bot'.1 hker v (by simp [hTv, h]))
  have hcv : RCLike.re ⟪T v, v⟫_𝕜 = c * ‖v‖ ^ 2 := by
    rw [hTv, inner_smul_left, inner_self_eq_norm_sq_to_K, RCLike.conj_ofReal, ← RCLike.ofReal_pow,
      ← RCLike.ofReal_mul, RCLike.ofReal_re]
  have hcnn : 0 ≤ c := by
    have := hT.re_inner_nonneg_left v
    rw [hcv] at this
    exact nonneg_of_mul_nonneg_left this (pow_pos (norm_pos_iff.2 hv.2) 2)
  refine ⟨c, lt_of_le_of_ne hcnn (Ne.symm hc0), fun w => ?_⟩
  rcases eq_or_ne w 0 with rfl | hw
  · simp
  have hle : c ≤ RCLike.re ⟪T w, w⟫_𝕜 / ‖w‖ ^ 2 :=
    ciInf_le ⟨0, by
      rintro _ ⟨x, rfl⟩
      exact div_nonneg (hT.re_inner_nonneg_left x) (by positivity)⟩ (⟨w, hw⟩ : {x : E // x ≠ 0})
  rwa [le_div_iff₀ (pow_pos (norm_pos_iff.2 hw) 2)] at hle

end LinearMap.IsPositive

namespace ContinuousLinearMap.IsPositive

variable {F : Type*} [NormedAddCommGroup F] [InnerProductSpace ℝ F] [FiniteDimensional ℝ F]

/-- For a positive operator `A` on a finite-dimensional real inner product space and `0 ≤ t < 1`,
the operator `(1 - t) • 1 + t • A` is positive and injective, so its determinant is positive. -/
theorem det_one_sub_smul_id_add_smul_pos {A : F →L[ℝ] F} (hA : A.IsPositive) {t : ℝ}
    (ht₀ : 0 ≤ t) (ht₁ : t < 1) :
    0 < ((1 - t) • ContinuousLinearMap.id ℝ F + t • A).det := by
  set B := (1 - t) • ContinuousLinearMap.id ℝ F + t • A
  have hB : B.IsPositive :=
    (ContinuousLinearMap.isPositive_id.smul_of_nonneg (by linarith)).add (hA.smul_of_nonneg ht₀)
  have hker : LinearMap.ker (B : F →ₗ[ℝ] F) = ⊥ := by
    refine LinearMap.ker_eq_bot'.2 fun v hv => ?_
    have hBv : B v = 0 := hv
    have hAv : 0 ≤ ⟪A v, v⟫_ℝ := hA.inner_nonneg_left v
    have h0 : ⟪B v, v⟫_ℝ = (1 - t) * ‖v‖ ^ 2 + t * ⟪A v, v⟫_ℝ := by
      simp [B, inner_add_left, inner_smul_left]
    rw [hBv, inner_zero_left] at h0
    have : ‖v‖ ^ 2 = 0 := by nlinarith [sq_nonneg ‖v‖, mul_nonneg ht₀ hAv]
    simpa using this
  exact ((ContinuousLinearMap.isPositive_toLinearMap_iff B).2 hB).det_pos hker

end ContinuousLinearMap.IsPositive
