"""Verify the addendum; every execution creates fresh scratch, never resumes."""
import argparse,hashlib,json,os,shutil,subprocess,sys,tempfile,time
from fractions import Fraction
from pathlib import Path


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def read(path):return json.loads(path.read_text())
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')

def verify_manifest(package):
 manifest=read(package/'SHA256_MANIFEST.json')
 for name,digest in manifest['files'].items():
  target=(package/name).resolve()
  if package not in target.parents:raise RuntimeError('Unsafe manifest path: '+name)
  if not target.is_file() or sha(target)!=digest:raise RuntimeError('Manifest mismatch: '+name)
 pins=read(package/'dependencies/PINS.json')
 for name,digest in pins['archives'].items():
  if sha(package/'dependencies'/name)!=digest:raise RuntimeError('Pinned archive mismatch: '+name)
 return len(manifest['files'])

def validate_cover(result,engine):
 if result.get('source_sha256')!=sha(engine):raise RuntimeError('Cover source hash mismatch')
 if result.get('coercivity_exact')!='1/1000':raise RuntimeError('Unexpected coercivity coefficient')
 if not result.get('complete') or result.get('pending_boxes')!=0:raise RuntimeError('INCOMPLETE cover: not a certificate')
 if Fraction(result['max_accepted_upper'])>=0:raise RuntimeError('Non-strict nonlocal bound')
 if not all(Fraction(v)<0 for v in result['local_certificate'][-1]['gershgorin_upper']):raise RuntimeError('Non-negative local Hessian bound')
 leaves=result['accepted']+result['empty']+result['local']
 if result['visited']!=2*leaves-1:raise RuntimeError('Inconsistent full binary tree counts')


def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--deps',type=Path,help='Optional directory containing flint/ for a compatible Python interpreter')
 ap.add_argument('--checks-only',action='store_true',help='Run manifests and exact Fraction checks; do not execute the cover')
 ap.add_argument('--max-nodes',type=int,default=2000000)
 ap.add_argument('--max-seconds',type=float,default=600)
 ap.add_argument('--output-parent',type=Path,help='Existing directory for a newly created output folder; default is package parent')
 args=ap.parse_args()
 package=Path(__file__).resolve().parent
 count=verify_manifest(package)
 # A fresh folder and source-only copies rule out historical checkpoint reuse.
 output=Path(tempfile.mkdtemp(prefix='coercivity_verify_',dir=str((args.output_parent or package.parent).resolve())))
 scratch=output/'scratch';scratch.mkdir()
 for name in ['cap_interval_arb.py','check_added_polynomial.py','check_improved_rho.py']:
  shutil.copy2(package/'code'/name,scratch/name)
 assert not (scratch/'cap_interval_arb_checkpoint.pkl').exists()
 env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
 if args.deps:
  deps=str(args.deps.resolve());env['PYTHONPATH']=deps+(os.pathsep+env['PYTHONPATH'] if env.get('PYTHONPATH') else '')
 summary={'status':'RUNNING','mode':'checks-only' if args.checks_only else 'full-cover','manifest_files_verified':count,'output':str(output),'fresh_scratch':str(scratch),'source_sha256':sha(scratch/'cap_interval_arb.py'),'started_unix':time.time()}
 write(output/'REPRODUCTION_SUMMARY.json',summary)
 try:
  for name in ['check_added_polynomial.py','check_improved_rho.py']:
   with (output/(Path(name).stem+'.log')).open('w') as log:
    subprocess.run([sys.executable,'-B',str(scratch/name)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
  for name in ['ADDED_POLYNOMIAL_CHECK.json','IMPROVED_RHO_RATIONAL_CHECK.json']:
   result=read(scratch/name)
   if result.get('status')!='PASS' or not all(result['checks'].values()):raise RuntimeError('Exact checker failed: '+name)
   shutil.copy2(scratch/name,output/name)
  if not args.checks_only:
   runtime_code="import flint,json,platform,sys; from pathlib import Path; print(json.dumps({'python':sys.version,'platform':platform.platform(),'version':flint.__version__,'root':str(Path(flint.__file__).resolve().parent)}))"
   runtime=json.loads(subprocess.check_output([sys.executable,'-B','-c',runtime_code],env=env,text=True))
   if runtime['version']!='0.6.0':raise RuntimeError('Requires python-flint==0.6.0; got '+runtime['version'])
   root=Path(runtime['root'])
   runtime['files_sha256']={str(path.relative_to(root)):sha(path) for path in sorted(root.rglob('*')) if path.is_file() and '__pycache__' not in path.parts}
   write(output/'ACTUAL_RUNTIME.json',runtime)
   with (output/'cover.log').open('w') as log:
    subprocess.run([sys.executable,'-B',str(scratch/'cap_interval_arb.py'),str(args.max_nodes),str(args.max_seconds)],env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
   result=read(scratch/'cap_interval_arb_results.json')
   shutil.copy2(scratch/'cap_interval_arb_results.json',output/'cap_interval_arb_results.json')
   validate_cover(result,scratch/'cap_interval_arb.py')
   if 'RESUMED' in (output/'cover.log').read_text():raise RuntimeError('Unexpected resumed checkpoint')
   summary['cover']={key:result[key] for key in ['visited','accepted','empty','local','pending_boxes','max_accepted_upper','seconds']}
  summary['status']='CHECKS_ONLY_PASS' if args.checks_only else 'COMPLETE_REPLAY'
 except Exception as exc:
  summary['status']='FAILED';summary['error']=str(exc)
  write(output/'REPRODUCTION_SUMMARY.json',summary)
  print(json.dumps(summary,indent=2));return 2
 summary['completed_unix']=time.time();write(output/'REPRODUCTION_SUMMARY.json',summary)
 print(json.dumps(summary,indent=2));return 0

if __name__=='__main__':sys.exit(main())
