FOUR-CELL COVARIANCE COERCIVITY AND THE RHO<=10^(-16) COROLLARY
Internally audited addendum, 30 October 2026

Result
The new validated covariance inequality is
  F(I)-F(C)>=(1/1000)||C-I||_F^2  for every C in the original Omega.
This improves the previous 10^(-12) coefficient by a factor of one billion.
It gives global same-frame centroid and L1 constants K=400000 and L=250000.
The existing analytic proof then establishes unique tetrahedral optimality
for balanced relaxed four-cell Gaussian assignments in every finite
ambient dimension >=3 and every 0<rho<=10^(-16). Lower dimensions have a
strict bound. The fixed-rho low-influence plurality corollary inherits the
same interval with its original quantifiers. Read proofs/COROLLARY_RHO_1E16.txt
for the complete statements, proof and explicit dependencies.

This addendum preserves the original 10^(-26) review package unchanged.
The entire original ZIP is included under dependencies/ and pinned by
SHA256 in dependencies/PINS.json. It in turn contains the endpoint,
stability, analytic assembly, prior audits and precise primary locators.
No claim is made for the full correlation interval or unequal masses.

What changed
Only the covariance objective gains (1/1000)||C-I||_F^2 and its exact
polynomial gradient/Hessian. The domain, pruning, clipping, center,
splitting and interval arithmetic mechanisms are unchanged.
proofs/ENGINE_DIFF.patch contains the complete engine diff;
proofs/DERIVATION.txt derives every added term and its downstream use.
The engine and new completed result are frozen by the package manifest.

One fresh full run of the new engine completed in about 168 seconds:
  visited 574557, accepted 245146, infeasible 39635, local 2498, pending 0.
The largest nonlocal corrected-objective upper gap was
-7.227592510400302e-12. The largest local Hessian Gershgorin upper bound
was -0.019278622387912548. The full log and result are in certificate/.
No historical checkpoint was loaded or included in this package.

Audits
The cleanroom agent reconstructed the inherited proof before adapting
its engine. The root agent independently inspected the complete diff,
all affected callers, and the improved analytic propagation. The root
also wrote 12 independent exact Fraction comparisons. Separately, this
package supplies a symbolic Fraction check for the added derivatives
and a 21-check Fraction verification of the entire rho hierarchy.
The numerical sampling in exploration/ selected the single candidate
kappa=1/1000 and is explicitly not a proof. NumPy is needed only to repeat
that optional exploration, not to verify the certificate.

The inherited runtime manifest is under runtime/. The interval computation
uses python-flint==0.6.0 with Arb at 100-bit precision. A second independently
implemented interval engine and external specialist review have not been
performed. No second same-source full replay of this new certificate has
been run during preparation of this addendum.

Reproduction
In a compatible Python environment install requirements.txt, then run:
  python verify_addendum.py
Alternatively supply an existing compatible directory containing flint/:
  python3.9 verify_addendum.py --deps /absolute/path/to/interval_deps
The interpreter must match any prebuilt extension's Python/architecture.

The wrapper verifies every packaged file hash and the pinned parent ZIP,
creates a NEW empty sibling output directory, copies only the engine and
exact checkers into fresh scratch, runs the exact checks, and recomputes
the complete new cover. Historical checkpoints are never used. It records
the actual runtime, logs, results and summary outside this package.
An incomplete cover fails even if the underlying engine exits normally.
The wrapper does not rerun the older endpoint cover: the pinned parent
package provides its own complete-reproduction wrapper for that task.

For lightweight verification without a cover or python-flint installation:
  python verify_addendum.py --checks-only
For larger runtime allowances use --max-seconds; default 600 seconds.
The package preparation ran the checks-only mode and an intentional
zero-node smoke run to confirm incomplete-cover rejection. Neither is a
second full replay. The preparation records are under audits/wrapper_smoke/.

No paid compute, publication, or external correspondence was performed.
