"""Exploratory binary64 sampling only; never a rigorous certificate."""
from pathlib import Path
import itertools,json,math
import numpy as np
here=Path(__file__).resolve().parent
rng=np.random.default_rng(20261030)
S=np.array(((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1)),dtype=float)
dverts=np.array(sorted(set(itertools.permutations((169/125,165/125,41/125)))))
cverts=-27/125*S
Cs=[]
for d in dverts:
 for c in cverts:
  Cs.append(((d[0],c[2],c[1]),(c[2],d[1],c[0]),(c[1],c[0],d[2])))
Cvertices=np.array(Cs)
# Independently randomize the two factors of the product polytope.
# Concentration < 1 puts substantial weight near its faces and vertices.
n=50000
d=rng.dirichlet(np.full(6,.22),n)@dverts
c=rng.dirichlet(np.full(4,.22),n)@cverts
C=np.zeros((n,3,3));C[:,range(3),range(3)]=d
C[:,2,1]=C[:,1,2]=c[:,0];C[:,2,0]=C[:,0,2]=c[:,1];C[:,1,0]=C[:,0,1]=c[:,2]
I=np.eye(3)
near=np.concatenate([I+(C[:1000]-I)*2.**(-j) for j in range(1,9)])
C=np.concatenate([Cvertices,C,near])
def width(C):
 det=np.linalg.det(C);out=np.zeros(C.shape[0])
 for i,j in itertools.combinations(range(4),2):
  k,l=[r for r in range(4) if r not in (i,j)]
  u=S[j]-S[i];v=S[k]-S[i];w=S[l]-S[i]
  bil=lambda u,v:np.einsum('i,nij,j->n',u,C,v)
  a=bil(u,u);p=bil(u,v);q=bil(u,w);r=bil(v,w)
  angle=np.arctan2(16*np.sqrt(a*det),p*q-a*r)
  out+=np.sqrt(a)*angle
 return out/(2*np.pi)**1.5
baseline=6*np.sqrt(8)*np.arccos(-1/3)/(2*np.pi)**1.5
Q=((C-I)**2).sum(axis=(1,2));gap=baseline-width(C);ratio=gap/Q
idx=int(np.argmin(ratio))
out={'method':'nonrigorous float64 sample, fixed seed 20261030','kappa':.001,'sample_count':len(C),'all_sampled_corrected_gaps_positive':bool(np.all(gap-.001*Q>0)),'minimum_sampled_gap_over_Q':float(ratio[idx]),'minimum_ratio_covariance':C[idx].tolist(),'minimum_corrected_gap':float(np.min(gap-.001*Q)),'baseline':baseline,'maximum_Q':float(Q.max())}
(here/'SAMPLE_RESULT.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
