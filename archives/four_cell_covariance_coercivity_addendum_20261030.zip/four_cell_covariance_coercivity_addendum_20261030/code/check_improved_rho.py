"""Exact rational hierarchy for a prospective extension; not a release update."""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json

def exp_bounds(x,n):
 lower=sum((x**j/factorial(j) for j in range(n+1)),F(0))
 ratio=x/(n+2)
 assert 0<=ratio<1
 return lower,lower+x**(n+1)/factorial(n+1)/(1-ratio)
checks={}
checks['exp_5_over_2_below_13']=exp_bounds(F(5,2),20)[1]<13
checks['exp_9_over_2_below_100']=exp_bounds(F(9,2),30)[1]<100
checks['exp_3_above_20']=exp_bounds(F(3),12)[0]>20
c0=F(1,500);cA=F(1,10000);edge=F(1,3)
checks['c0_lower_bound_from_pi_lt_4']=8*4*13<500
checks['cA_lower_bound_from_pi_lt_4']=2*4<9 and 32*3*100<10000
checks['edge_lower_bound_from_endpoint_formula']=F(2,3)*F(3,16)>edge**2
kappa=F(1,1000);K=400000;L=250000;rho=F(1,10**16);R=24;sigma=F(1,K+1)
checks['near_covariance_coefficient']=6/kappa==6000
checks['sqrt_2000_lt_45']=2000<45**2
checks['near_centroid_K']=46**2<K
checks['far_centroid_K']=4*10**5<=K
checks['sqrt_6000_lt_78']=6000<78**2
checks['near_distance_L']=(9+6*78)**2<L
checks['far_distance_L']=10**5<=L
checks['competitive_near_regime']=3*rho/4<F(1,100000)
eps=F(25,20**24);A2=96/c0;CQ=19200/c0;CJ=3*A2/cA;BR=2*(1+3*R)/edge
ER=2*CJ*eps+36*(2*K+1)*A2*eps**2
checks['tail_hierarchy']=ER<sigma/4
checks['rho_le_1_over_16']=rho<=F(1,16)
checks['potential_hierarchy']=2*BR*rho<sigma/8
checks['quadratic_hierarchy']=CQ*rho<sigma/4
checks['repair_capacity_hierarchy']=rho<cA*cA/(108*L)
checks['repair_capacity_squared']=3*L*rho/4<(cA/12)**2
margin=2-(2-sigma)/(1-BR*rho)-ER-CQ*rho
checks['direct_final_margin']=margin>sigma/4
out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'parameters':{'kappa':str(kappa),'K':K,'L':L,'rho':str(rho),'R':R},'rational_bounds':{'epsilon_R_upper':str(eps),'tail_error_upper':str(ER),'direct_final_margin_lower':str(margin),'required_margin':str(sigma/4),'repair_rho_limit_lower':str(cA*cA/(108*L))},'scope':'Prospective analytic assembly constants conditional on new completed covariance cover and unchanged audited lemmas. Original rho theorem/release unchanged.'}
(Path(__file__).resolve().parent/'IMPROVED_RHO_RATIONAL_CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
assert all(checks.values()),checks
