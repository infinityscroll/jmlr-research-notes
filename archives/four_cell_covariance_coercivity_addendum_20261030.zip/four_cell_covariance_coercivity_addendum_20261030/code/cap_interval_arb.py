"""Separate covariance-coercivity certificate, kappa=1/1000.

Certifies F(C)+kappa*||C-I||_F^2 <= F(I) on the original domain.
Derived from the frozen endpoint engine; see ENGINE_DIFF.patch and DERIVATION.txt.
Incomplete runs are NOT proofs. Arithmetic stack and cover semantics are inherited.
"""
import itertools,json,time,heapq,sys,math,pickle,hashlib
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parent/'interval_deps'))
from flint import arb,ctx
ctx.prec=100
class ArbIntervals:
 pi=arb.pi()
 @staticmethod
 def mpf(x):
  if isinstance(x,(list,tuple)):return arb(x[0]).union(arb(x[1]))
  return arb(x)
 @staticmethod
 def sqrt(x):return x.sqrt()
 @staticmethod
 def atan2(y,x):return ArbIntervals.pi/2-(x/y).atan()
iv=ArbIntervals()
COERCIVITY=iv.mpf(1)/1000
S=((1,1,1),(1,-1,-1),(-1,1,-1),(-1,-1,1))
E=(((1,0,0),(0,0,0),(0,0,-1)),((0,0,0),(0,1,0),(0,0,-1)),
   ((0,0,0),(0,0,1),(0,1,0)),((0,0,1),(0,0,0),(1,0,0)),
   ((0,1,0),(1,0,0),(0,0,0)))
def bil(u,C,v):return sum(u[i]*C[i][j]*v[j] for i in range(3) for j in range(3))
edges=[]
for i,j in itertools.combinations(range(4),2):
 k,l=[x for x in range(4) if x not in (i,j)]
 u=tuple(S[j][n]-S[i][n] for n in range(3));v=tuple(S[k][n]-S[i][n] for n in range(3));w=tuple(S[l][n]-S[i][n] for n in range(3))
 deriv=[tuple(bil(a,e,b) for a,b in [(u,u),(u,v),(u,w),(v,w)]) for e in E]
 edges.append((u,v,w,deriv))
K=1/(2*iv.pi*(2*iv.pi).sqrt())
def lo(x):return math.nextafter(float(x.lower()),-math.inf)
def hi(x):return math.nextafter(float(x.upper()),math.inf)
def mag(x):return max(abs(lo(x)),abs(hi(x)))
def sq(x):
 a=x.abs_lower();b=x.abs_upper()
 return (a*a).union(b*b)
def clipped(x,l,u):return iv.mpf([max(lo(x),l),min(hi(x),u)])
def evaluate(box,hessian=False,objective=False):
 x=[iv.mpf([a,b]) for a,b in box];d1,d2,c1,c2,c3=x;d3=3-d1-d2
 C=((d1,c3,c2),(c3,d2,c1),(c2,c1,d3))
 det=d1*d2*d3+2*c1*c2*c3-d1*sq(c1)-d2*sq(c2)-d3*sq(c3)
 # The pair-union refinement gives Cii<=1.352. With Cii>=.328,
 # log(det) concavity at the24 vertices gives det>=830544/1953125.
 # The relaxed bounds below also absorb the center's rounding tolerance.
 det=clipped(det,.424,1.00000000000001)
 dd=(d2*d3-d1*d2-sq(c1)+sq(c3),d1*d3-d1*d2-sq(c2)+sq(c3),
     2*c2*c3-2*d1*c1,2*c1*c3-2*d2*c2,2*c1*c2-2*d3*c3)
 radial=iv.mpf(0);grad=[iv.mpf(0) for _ in range(5)]
 value=iv.mpf(0);value_grad=[iv.mpf(0) for _ in range(5)]
 H=[[iv.mpf(0) for _ in range(5)] for _ in range(5)] if hessian else None
 for u,v,w,deriv in edges:
  a=clipped(bil(u,C,u),4.863,12.417)
  p=bil(u,C,v);q=bil(u,C,w);r=bil(v,C,w)
  N=p*q-a*r;y=16*iv.sqrt(a*det);alpha=iv.atan2(y,N);length=iv.sqrt(a)
  radial+=alpha*(a-8)/length
  value+=alpha*length
  da=[row[0] for row in deriv];dalpha=[]
  for j,(aj,pj,qj,rj) in enumerate(deriv):
   value_grad[j]+=alpha*aj/length
   if objective and not hessian:continue
   Nj=pj*q+p*qj-aj*r-a*rj;yj=y/2*(aj/a+dd[j]/det)
   denominator=clipped(sq(N)+sq(y),527.,1e9)
   alj=(N*yj-y*Nj)/denominator;dalpha.append(alj)
   grad[j]+=alj*(a-8)/length+alpha*aj*(a+8)/(2*a*length)
  if hessian:
   for i in range(5):
    for j in range(5):H[i][j]+=da[i]*(dalpha[j]/length-alpha*da[j]/(2*a*length))
 radial*=K/2;grad=[z*K/2 for z in grad]
 value*=K;value_grad=[z*K/2 for z in value_grad]
 # Q=||C-I||_F^2. These are exact polynomial additions to F and its derivatives.
 Q=sq(d1-1)+sq(d2-1)+sq(d3-1)+2*(sq(c1)+sq(c2)+sq(c3))
 value+=COERCIVITY*Q
 Qgrad=(4*d1+2*d2-6,2*d1+4*d2-6,4*c1,4*c2,4*c3)
 value_grad=[g+COERCIVITY*qg for g,qg in zip(value_grad,Qgrad)]
 if hessian:
  H=[[z*K/2 for z in row] for row in H]
  for i in range(5):H[i][i]+=4*COERCIVITY
  H[0][1]+=2*COERCIVITY;H[1][0]+=2*COERCIVITY
 return (value,value_grad,H) if objective else (radial,grad,H)
def local_test():
 out=[]
 for radius in [.05,.02,.01,.005,.002,.001,.0005]:
  box=[(1-radius,1+radius)]*2+[(-radius,radius)]*3
  _,_,H=evaluate(box,True)
  rows=[hi(H[i][i]+sum(iv.mpf(mag(H[i][j])) for j in range(5) if j!=i)) for i in range(5)]
  out.append({'radius':radius,'gershgorin_upper':rows})
  if max(rows)<0:return radius,out
 return None,out
def feasible_center(box):
 low=.328;eta=.216;cap=3-low
 # By coordinate permutation and the tetrahedral sign group it suffices
 # to cover d1>=d2>=d3 and c1,c2>=0. The center need only belong to the
 # larger convex capped polytope, since the derivative bounds hold there.
 if hi(iv.mpf(box[0][1])-box[1][0])<0:return None
 if hi(iv.mpf(box[0][1])+2*iv.mpf(box[1][1]))<3:return None
 if lo(iv.mpf(box[0][0])+box[1][0])>=hi(3-iv.mpf(41)/125):return None
 for s in S:
  bound=sum(iv.mpf(s[i])*(box[i+2][0] if s[i]>0 else box[i+2][1]) for i in range(3))
  if lo(bound)>=hi(iv.mpf(27)/125):return None
 x=[(a+b)/2 for a,b in box]
 if x[0]+x[1]>cap:
  lows=box[0][0]+box[1][0];t=(cap-lows)/(x[0]+x[1]-lows)
  t*=1-1e-13
  for i in range(2):x[i]=box[i][0]+t*(x[i]-box[i][0])
 for s in S:
  z=sum(s[i]*x[i+2] for i in range(3))
  if z>eta:
   corner=[box[i+2][0] if s[i]>0 else box[i+2][1] for i in range(3)]
   zmin=sum(s[i]*corner[i] for i in range(3));t=(z-eta)/(z-zmin)
   t=min(1.,t+1e-13)
   for i in range(3):x[i+2]+=t*(corner[i]-x[i+2])
 x=[min(b,max(a,z)) for (a,b),z in zip(box,x)]
 # Center and every feasible point are in this convex slightly enlarged
 # domain; the clipping bounds .424,4.863,12.417 remain valid there.
 assert x[0]+x[1]<=cap+1e-10 and min(x[:2])>=low-1e-10
 assert max(x[0],x[1],3-x[0]-x[1])<=1.352+1e-10
 assert all(sum(s[i]*x[i+2] for i in range(3))<=eta+1e-10 for s in S)
 return x
def run(max_nodes=10000,max_seconds=120):
 start=time.monotonic();radius,local=local_test();print('LOCAL',json.dumps(local),flush=True)
 if radius is None:return {'complete':False,'reason':'no certified local cube','local':local}
 baseline=evaluate([(1.,1.),(1.,1.),(0.,0.),(0.,0.),(0.,0.)],objective=True)[0]
 root=((math.nextafter(1.,-math.inf),math.nextafter(1.352,math.inf)),
       (math.nextafter(.824,-math.inf),math.nextafter(1.352,math.inf)),
       (0.,math.nextafter(.216,math.inf)),(0.,math.nextafter(.216,math.inf)),
       (math.nextafter(-.216,-math.inf),math.nextafter(.216,math.inf)))
 queue=[(-10.,0,root)];serial=0;visited=accepted=empty=local_count=0;max_accepted=-1e99
 here=Path(__file__).resolve().parent;state_path=here/'cap_interval_arb_checkpoint.pkl'
 source_hash=hashlib.sha256(Path(__file__).read_bytes()).hexdigest()
 if state_path.exists():
  state=pickle.loads(state_path.read_bytes())
  if state.get('source_sha256')==source_hash:
   queue=state['queue'];serial=state['serial'];visited=state['visited'];accepted=state['accepted'];empty=state['empty'];local_count=state['local'];max_accepted=state['max_accepted']
   print('RESUMED',visited,len(queue),flush=True)
 start_visited=visited
 while queue and visited-start_visited<max_nodes and time.monotonic()-start<max_seconds:
  _,_,box=heapq.heappop(queue);visited+=1
  center=feasible_center(box)
  if center is None:empty+=1;continue
  if all(a>=base-radius and b<=base+radius for (a,b),base in zip(box,[1,1,0,0,0])):
   local_count+=1;continue
  rb,grad,_=evaluate(box,objective=True);rc,_,_=evaluate([(z,z) for z in center],objective=True)
  distances=[math.nextafter(max(abs(z-a),abs(b-z)),math.inf) for (a,b),z in zip(box,center)]
  error=sum(iv.mpf(mag(g))*d for g,d in zip(grad,distances))
  upper=min(hi(rb-baseline),hi(rc+error-baseline))
  if upper<0:
   accepted+=1;max_accepted=max(max_accepted,upper);continue
  priorities=[mag(g)*(b-a) for g,(a,b) in zip(grad,box)]
  j=max(range(5),key=lambda i:priorities[i]);a,b=box[j];mid=(a+b)/2
  for interval in [(a,mid),(mid,b)]:
   child=list(box);child[j]=interval;serial+=1
   heapq.heappush(queue,(-upper,serial,tuple(child)))
  if visited%1000==0:print('PROGRESS',visited,len(queue),accepted,empty,local_count,round(time.monotonic()-start,2),flush=True)
 out={'complete':not queue,'source_sha256':source_hash,'bound':'direct F(C)+(1/1000)||C-I||_F^2-F(I) via interval gradient mean-value enclosure; local cube via negative Hessian', 'coercivity_exact':'1/1000','domain':'pair-union-refined, d_i in[.328,1.352], trace3, S_i.c<=.216; symmetry d1>=d2>=d3,c1,c2>=0','visited':visited,'pending_boxes':len(queue),'accepted':accepted,'empty':empty,'local':local_count,'local_radius':radius,'local_certificate':local,'max_accepted_upper':max_accepted,'seconds':time.monotonic()-start,'warning':'prototype: independent interval arithmetic and coverage audit required even if complete'}
 state_path.write_bytes(pickle.dumps({'source_sha256':source_hash,'queue':queue,'serial':serial,'visited':visited,'accepted':accepted,'empty':empty,'local':local_count,'max_accepted':max_accepted}))
 (here/'cap_interval_arb_results.json').write_text(json.dumps(out,indent=2)+'\n')
 print('RESULT',json.dumps(out),flush=True);return out
if __name__=='__main__':run(int(sys.argv[1]) if len(sys.argv)>1 else 10000,float(sys.argv[2]) if len(sys.argv)>2 else 120)
