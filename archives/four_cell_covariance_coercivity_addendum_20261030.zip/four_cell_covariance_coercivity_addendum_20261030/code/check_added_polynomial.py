"""Exact independent symbolic differentiation of the added polynomial."""
from fractions import Fraction as F
from pathlib import Path
import json
N=5;zero=(0,)*N

def plus(*polys):
 result={}
 for p in polys:
  for key,val in p.items(): result[key]=result.get(key,F(0))+val
 return {key:val for key,val in result.items() if val}

def scale(p,a):return {key:val*a for key,val in p.items() if val*a}
def times(p,q):
 result={}
 for a,x in p.items():
  for b,y in q.items():
   key=tuple(i+j for i,j in zip(a,b));result[key]=result.get(key,F(0))+x*y
 return {key:val for key,val in result.items() if val}
def var(j):return {tuple(int(i==j) for i in range(N)):F(1)}
def constant(a):return {zero:F(a)} if a else {}
def derivative(p,j):
 result={}
 for key,val in p.items():
  if key[j]:
   new=list(key);new[j]-=1;result[tuple(new)]=val*key[j]
 return result
x=[var(j) for j in range(N)]
d=[plus(x[0],constant(-1)),plus(x[1],constant(-1)),plus(constant(2),scale(x[0],-1),scale(x[1],-1))]
Q=plus(*(times(z,z) for z in d),*(scale(times(z,z),2) for z in x[2:]))
claimed_grad=[plus(scale(x[0],4),scale(x[1],2),constant(-6)),plus(scale(x[0],2),scale(x[1],4),constant(-6)),*(scale(z,4) for z in x[2:])]
claimed_H=[[4*int(i==j)+2*int((i,j) in [(0,1),(1,0)]) for j in range(N)] for i in range(N)]
checks={'gradient_exact':all(derivative(Q,j)==claimed_grad[j] for j in range(N)),'Hessian_exact':all(derivative(claimed_grad[i],j)==constant(claimed_H[i][j]) for i in range(N) for j in range(N))}
# Original 1e-12 stability proof improves without changing its estimates:
# ||C-I||^2 <= (6/kappa) Delta = 6000 Delta.
# (6 sqrt(6000)+9)^2 < 225000 follows after isolating its radical.
checks['new_L_near']=F(225000-216000-81)**2 > F(108)**2*6000
checks['new_L_far']=225000>=100000
# (sqrt(2000)+1)^2 < 2100, and K=400000 retains the old far bound.
checks['new_K_near']=F(2100-2001)**2 > 4*2000
checks['new_K_far']=400000>=4*100000
# Local Hessian Gershgorin increases are bounded by kappa*(6,6,4,4,4).
checks['local_margin_preserved']=all(F(v)+F(inc,1000)<0 for v,inc in zip([-.04885152684743248,-.04885152684743248,-.032843698564079864,-.032843698564079864,-.02327862241701638],[6,6,4,4,4]))
assert all(checks.values()),checks
out={'status':'PASS','checks':checks,'kappa':'1/1000','gradient':['4*d1+2*d2-6','2*d1+4*d2-6','4*c1','4*c2','4*c3'],'Hessian':claimed_H,'implied_K_safe':400000,'implied_L_safe':225000,'scope':'Exact polynomial identities and safe downstream constants; complete cover required separately.'}
(Path(__file__).resolve().parent/'ADDED_POLYNOMIAL_CHECK.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
